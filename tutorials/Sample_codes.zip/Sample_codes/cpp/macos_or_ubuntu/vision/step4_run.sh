g++ -o run step4_letter_detection.cc

g++ -I /usr/local/include/opencv4/ -std=c++11 -o run step4_letter_detection.cc -lopencv_core -lopencv_imgcodecs -lopencv_imgproc -lopencv_highgui
./run
