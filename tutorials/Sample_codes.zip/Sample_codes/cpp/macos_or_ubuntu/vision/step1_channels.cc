#include <string>
#include <iostream>
#include "opencv2/opencv.hpp"


using namespace std;
using namespace cv;



int main(int argc, char* argv[])
{

	
   ///////////////////////////////////////////// read image    ///////////////////////////////////////////// 
    Mat image;
    image = imread("img/vision.png", IMREAD_UNCHANGED);   // Read the file

    if(! image.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
        return -1;
    }

   /////////////////////////////////////////////  gray scale    ///////////////////////////////////////////// 
    Mat image_gray;
    cvtColor( image, image_gray, COLOR_BGR2GRAY );


   /////////////////////////////////////////////  Threshold    ///////////////////////////////////////////// 

   Mat image_threshold;
   threshold( image_gray, image_threshold, 127, 255,0 );  //binary


   /////////////////////////////////////////////  Show image   ///////////////////////////////////////////// 

    namedWindow( "Display window", WINDOW_AUTOSIZE );// Create a window for display.
    imshow( "Display window", image_threshold );     // Show our image inside it.



    waitKey(0);                                          // Wait for a keystroke in the window
    return 0;
}



