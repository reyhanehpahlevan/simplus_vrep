#include <string>
#include <iostream>
#include "opencv2/opencv.hpp"



using namespace std;
using namespace cv;



int main(int argc, char* argv[])
{

	
   ///////////////////////////////////////////// read image    ///////////////////////////////////////////// 
    Mat image;
    image = imread("img/vision.png", IMREAD_UNCHANGED);   // Read the file

    if(! image.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
        return -1;
    }

   /////////////////////////////////////////////  gray scale    ///////////////////////////////////////////// 
    Mat image_gray;
    cvtColor( image, image_gray, COLOR_BGR2GRAY );


   /////////////////////////////////////////////  Threshold    ///////////////////////////////////////////// 

   Mat image_threshold;
   threshold( image_gray, image_threshold, 127, 255,0 );  //binary

   /////////////////////////////////////////////  find countors  ///////////////////////////////////////////// 
   // Contours can be explained simply as a curve joining all the continuous points (along the boundary),
   // having same color or intensity. The contours are a useful tool for shape analysis and object detection and recognition.
   vector<vector<Point> > contours;
   vector<Vec4i> hierarchy;
   findContours( image_threshold, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0) );
   //Draw countours
   Mat drawing = Mat::zeros( image_threshold.size(), CV_8UC3 );
   RNG rng(12345);

   for( int i = 0; i< contours.size(); i++ )
     {
       Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
       drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0, Point() );
     }
  // Show countours
     namedWindow( "Image", WINDOW_AUTOSIZE );
     imshow( "Display window", drawing );    
   


    waitKey(0);                                          // Wait for a keystroke in the window
    return 0;
}



