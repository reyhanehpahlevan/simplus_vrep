g++ -o run step3_bouding.cc

g++ -I /usr/local/include/opencv4/ -std=c++11 -o run step3_bouding.cc -lopencv_core -lopencv_imgcodecs -lopencv_imgproc -lopencv_highgui
./run
