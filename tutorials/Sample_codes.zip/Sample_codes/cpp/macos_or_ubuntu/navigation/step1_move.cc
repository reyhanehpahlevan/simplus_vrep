#include <iostream>
#include <memory>
#include <string>
#include <stdlib.h>     /* abs */

using namespace std;


int team_size,robot_per_team,color_sensor_size,proximity_sensor_size,server_time;

extern "C" {


 char *  start(int _team_size,int _robot_per_team,int _color_sensor_size,int _proximity_sensor_size){
  team_size=_team_size;
  robot_per_team=_robot_per_team;
  color_sensor_size=_color_sensor_size;
  proximity_sensor_size=_proximity_sensor_size;
  server_time=0;
  return "Dragon1";
}


char * end(){
  return  "The Ending Message";

  
}

 char* play(int colors_1[],int colors_2[],int colors_3[],int proximity_detected[],float proximity_distances[],float pos[],int image_r[],int image_g[],int image_b[],int thermal[],int *led_color_id,float *wheel_linear, float *wheel_angular,float * action_x,float * action_y,float * action_z){

    /* led_color_id: 1---> red  2---> green 3---> blue 4---> off
       colors_1[]: color sensor 1 value, colors are defined by (r,g,b), colors_1[0]-->r value  colors_1[1]-->g value colors_1[2]-->b value
       colors_2[]: color sensor 2 value, colors are defined by (r,g,b), colors_2[0]-->r value  colors_2[1]-->g value colors_3[2]-->b value
       colors_3[]: color sensor 3 value, colors are defined by (r,g,b), colors_3[0]-->r value  colors_2[1]-->g value colors_3[2]-->b value
       
       wheel_linear: linear velocity 
       wheel_angular: angular velocity
       
       proximity_distances[]: values of proximity sensor receptively, you can find the order numbers by clicking on each proximity sensor of robot model in model tree,vrep
       proximity_detected[]: the array length is equal to number of proximity sensor receptively and it's value is 0 or 1 for each proximity. 1 shows that the obstacle is detected
       
       pos[]: pos[0] --> x  pos[1] --> y   pos[2]--> z
       
       return char*: action name if action is detected or empty string
       action_x: the x position of the detected action
       action_y: the y position of the detected action
       action_z: the z position of the detected action
    */
    // Your code will be here
    // You get unique ID of our current robot in the field id
    // You can read data from observation and server
    // You should fill the command for your robots


    // TODO: In This tutorial we want to make robot do below instruction:
    //   1. Go Forward for 20 cycle
    //   2. Turn Left for 10 cycle
    //   3. Go Forward for 20 cycle
    //   4. Turn Right for 10 cycle
    //   5. Go Forward for 20 cycle
    //   5. Go Backward for 10 cycle
    //   6. Go Backward for 10 cycle
    //   7.  random
    //   8. Have Fun with playing with robot and changing LED colors :)

    char direction = 'F';
    if (server_time < 20)
        direction = 'F'; // Make Robot Go forward for 20 cycle
    else if (server_time < 20 + 10)
        direction = 'L';  // Make Robot Turn left for 10 cycle
    else if (server_time < 20 + 10 + 20)
        direction = 'F';  // Go forward
    else if (server_time < 20 + 10 + 20 + 10 + 10)
        direction = 'R';  // Fill To Turn Right
    else if (server_time < 20 + 10 + 20 + 10 + 10 + 10)
        direction = 'F';  // Go Forward
    else if (server_time < 20 + 10 + 20 + 10 + 10 + 20 + 10)
        direction = 'B';  // Fill To Go Backward
    else if (server_time < 20 + 10 + 20 + 10 + 10 + 20 + 10 + 10)
        direction = 'S';  // Fill To Stop
    else if (server_time %10  < 4) // 3 step
        direction = 'L'; 
    else
        direction = 'F'; 


    if (direction == 'F'){
        *wheel_linear =  0.1;
        *wheel_angular  = 0.0;
        *led_color_id = 2; // Make it green
      }
    if (direction == 'B'){
        *wheel_linear = -0.1; // Set a negative value to make robot go backward (See. Forward)
        *wheel_angular  = 0.0; // Set the 0 value to make robot go backward (See. Forward)
        *led_color_id = 2; // Make it green
      }
    if (direction == 'L'){
        *wheel_linear = 0.0;
        *wheel_angular  = 0.3;
         *led_color_id = 3; // blue
       }
    if (direction == 'R'){
        *wheel_linear = 0.0; // Set the 0 value to make robot turn right (See. Turn Left)
        *wheel_angular  = -0.3;  // Set a negative value to make robot turn right (See. Turn Left)
        *led_color_id = 3; // Make it blue
      }
    if (direction == 'S'){
        *wheel_linear = 0.0;
        *wheel_angular  = 0.0;
        *led_color_id = 1; //red
      }
  
  server_time++;  
  return "";

}

}
