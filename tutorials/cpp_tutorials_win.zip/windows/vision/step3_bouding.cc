
//brew install opencv
// g++ -std=c++11 ocr_simple.cpp 
// g++ -I /usr/local/include/opencv4/ -std=c++11 -o out ocr_simple.cpp 
// g++ -I /usr/local/include/opencv4/ -std=c++11 -o out ocr_simple.cpp -lopencv_core -lopencv_imgcodecs -lopencv_imgproc -lopencv_highgui

#include <string>
#include <iostream>
#include "opencv2/opencv.hpp"
// #include "opencv2/highgui/highgui.hpp"
// #include "opencv2/imgproc/imgproc.hpp"
// #include "opencv2/imgcodecs.hpp"
// #include "opencv2/core/core.hpp"


using namespace std;
using namespace cv;



int main(int argc, char* argv[])
{

	cout << "salam";
	
   ///////////////////////////////////////////// read image    ///////////////////////////////////////////// 
    Mat image;
    image = imread("img/vision.png", IMREAD_UNCHANGED);   // Read the file

    if(! image.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
        return -1;
    }

   /////////////////////////////////////////////  gray scale    ///////////////////////////////////////////// 
    Mat image_gray;
    cvtColor( image, image_gray, COLOR_BGR2GRAY );


   /////////////////////////////////////////////  Threshold    ///////////////////////////////////////////// 

   Mat image_threshold;
   threshold( image_gray, image_threshold, 127, 255,0 );  //binary

   /////////////////////////////////////////////  find countors  ///////////////////////////////////////////// 
   // Contours can be explained simply as a curve joining all the continuous points (along the boundary),
   // having same color or intensity. The contours are a useful tool for shape analysis and object detection and recognition.
   vector<vector<Point> > contours;
   vector<Vec4i> hierarchy;
   findContours( image_threshold, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0) );


   /////////////////////////////////////////////  find bounding boxes  ///////////////////////////////////////////// 
  /// Approximate contours to polygons + get bounding rects and circles
  vector<vector<Point> > contours_poly( contours.size() );
  vector<Rect> boundRect( contours.size() );
  vector<Point2f>center( contours.size() );
  vector<float>radius( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
       boundRect[i] = boundingRect( Mat(contours_poly[i]) );
       minEnclosingCircle( (Mat)contours_poly[i], center[i], radius[i] );
     }


  RNG rng(12345);
  /// Draw polygonal contour + bonding rects + circles
  Mat drawing = Mat::zeros( image_threshold.size(), CV_8UC3 );
  for( int i = 0; i< contours.size(); i++ )
     {
       Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
       drawContours( drawing, contours_poly, i, color, 1, 8, vector<Vec4i>(), 0, Point() );
       rectangle( drawing, boundRect[i].tl(), boundRect[i].br(), color, 2, 8, 0 );
       circle( drawing, center[i], (int)radius[i], color, 2, 8, 0 );
     }

  /// Show in a window
  namedWindow( "Bounding", WINDOW_AUTOSIZE );
  imshow( "Bounding", drawing );




    waitKey(0);                                          // Wait for a keystroke in the window
    return 0;
}



