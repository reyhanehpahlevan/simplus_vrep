
#include <string>
#include <iostream>
#include "opencv2/opencv.hpp"



using namespace std;
using namespace cv;



Rect victim;

/////////////////////////////////////////////   find_victim_big   ///////////////////////////////////////////// 

int find_victim_big(Mat image){


    if(! image.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
        return -1;
    }

   /////////////////////////////////////////////  gray scale    ///////////////////////////////////////////// 
    Mat image_gray;
    cvtColor( image, image_gray, COLOR_BGR2GRAY );


   /////////////////////////////////////////////  Threshold    ///////////////////////////////////////////// 

   Mat image_threshold;
   threshold( image_gray, image_threshold, 127, 255,0 );  //binary

   /////////////////////////////////////////////  find countors  ///////////////////////////////////////////// 
   // Contours can be explained simply as a curve joining all the continuous points (along the boundary),
   // having same color or intensity. The contours are a useful tool for shape analysis and object detection and recognition.
   vector<vector<Point> > contours;
   vector<Vec4i> hierarchy;
   findContours( image_threshold, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0) );


   /////////////////////////////////////////////  find bounding boxes  ///////////////////////////////////////////// 
  /// Approximate contours to polygons + get bounding rects and circles
  vector<vector<Point> > contours_poly( contours.size() );
  vector<Rect> boundRect( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
       boundRect[i] = boundingRect( Mat(contours_poly[i]) );
       int w = boundRect[i].width ;
       int h = boundRect[i].height;
       if (w<40 || h<40 || w>200 || h>200)
       	  continue;
       if(image.size().width-w <10 || image.size().height-h <20)
          continue;	
       cout<<w<<"----"<<h<<"----"<<"\n";
       victim = boundRect[i];
       return 1;
     }

    return 0;
  }

/////////////////////////////////////////////   find_victim   ///////////////////////////////////////////// 

int find_victim(Mat image){


    if(! image.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
        return -1;
    }

   /////////////////////////////////////////////  gray scale    ///////////////////////////////////////////// 
    Mat image_gray;
    cvtColor( image, image_gray, COLOR_BGR2GRAY );


   /////////////////////////////////////////////  Threshold    ///////////////////////////////////////////// 

   Mat image_threshold;
   threshold( image_gray, image_threshold, 127, 255,0 );  //binary

   /////////////////////////////////////////////  find countors  ///////////////////////////////////////////// 
   // Contours can be explained simply as a curve joining all the continuous points (along the boundary),
   // having same color or intensity. The contours are a useful tool for shape analysis and object detection and recognition.
   vector<vector<Point> > contours;
   vector<Vec4i> hierarchy;
   findContours( image_threshold, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0) );


   /////////////////////////////////////////////  find bounding boxes  ///////////////////////////////////////////// 
  /// Approximate contours to polygons + get bounding rects and circles
  vector<vector<Point> > contours_poly( contours.size() );
  vector<Rect> boundRect( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
       boundRect[i] = boundingRect( Mat(contours_poly[i]) );
       int w = boundRect[i].width ;
       int h = boundRect[i].height;
       if (w<20 || h<20 || w>200 || h>200)
       	  continue;
       if(image.size().width-w <10 || image.size().height-h <20)
          continue;	
       cout<<w<<"----"<<h<<"----"<<"\n";
       victim = boundRect[i];
       return 1;
     }

    return 0;
  }


int main(int argc, char* argv[])
{

  ///////////////////////////////////////////// read image    ///////////////////////////////////////////// 
    Mat image;
    image = imread("img/test3.png", IMREAD_UNCHANGED);   // Read the file
   
  
  if(find_victim(image) == 1 ){
	  /// Draw rectangle around letter
	  RNG rng(12345);
	  Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
	  rectangle( image, victim.tl(), victim.br(), color, 2, 8, 0 );
	}
   else{
   	  cout << "Victim not found";
   }
  // /// Show in a window
  namedWindow( "Letter detection", WINDOW_AUTOSIZE );
  imshow( "Letter detection", image );




    waitKey(0);                                          // Wait for a keystroke in the window
    return 0;
}



