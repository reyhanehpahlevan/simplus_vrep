#include <iostream>
#include <memory>
#include <string>
#include <stdlib.h>     /* abs */
#include<time.h> 
#include "opencv2/opencv.hpp"
#define EXPORT  __declspec(dllexport)


using namespace std;
using namespace cv;

int image[128][128][3];  // rgb
Mat image_cv;  // bgr

float visited_victims_x[20];
float visited_victims_y[20];
float visited_victims_z[20];
int visited_victims_num=0;

int team_size,robot_per_team,color_sensor_size,proximity_sensor_size,server_time;

extern "C" {



char last_turn='F';
char control(int proximity_detected[],float proximity_distances[],int colors_1[],int colors_2[],int colors_3[]){


   //move strategy   
    //
    //    Map of Sensor location on Robot
    //
    //           /--- *2* ---- *3* ---\
    //          /                      \
    //        *1*                      *4*
    //         |       SIMPLUS          |
    //        *0*        ROBOT         *5*
    //         |                        |
    //          \                      /
    //          *7* -----------------*6*
    // 

    ////////////////////////////// check Holes ////////////////////////////////
    int  is_black_center = 0;
    int is_black_left = 0; 
    int is_black_right = 0;
    int sum_center = (colors_1[0] + colors_1[1] + colors_1[2]);
    if ( sum_center >5 && sum_center<30)
        is_black_center = 1;  

    int sum_left = (colors_2[0] + colors_2[1] + colors_2[2]); 
    if ( sum_left >5 && sum_left<30)
        is_black_left = 1;  

    int sum_right = (colors_3[0] + colors_3[1] + colors_3[2]);
    if ( sum_right >5 && sum_right<30)
          is_black_right = 1;  


    ////////////////////////////// check proximity sensor's status ////////////////////////////////

    int is_obstacle_left = 0;
    int is_obstacle_right = 0;
    int is_obstacle_Front = 0;

    float min_dist = 0.1; //smaller number means robot more afraid of hitting obstacles
    if( (proximity_detected[2] == 1 &&  proximity_distances[2] < min_dist) || (proximity_detected[3] == 1 &&  proximity_distances[3] < min_dist))
          is_obstacle_Front = 1;
    if( (proximity_detected[1] == 1 &&  proximity_distances[1] < min_dist) || (proximity_detected[0] == 1 &&  proximity_distances[0] < min_dist))
          is_obstacle_left = 1;
    if( (proximity_detected[4] == 1 &&  proximity_distances[4] < min_dist) || (proximity_detected[5] == 1 &&  proximity_distances[5] < min_dist))
          is_obstacle_right = 1;

   ///////////// Decide ///////////////
    char direction = 'F';

    if ( is_obstacle_Front  == 0 && is_black_center == 0 )
    {
        direction = 'F';
    }
    else if ( is_obstacle_left ==0 && is_black_left == 0 ){
        direction = 'L';
    }

    else if ( is_obstacle_right ==0 && is_black_right == 0 ){
        direction = 'R';
    }
    else if  (is_obstacle_left ==1 &&  is_obstacle_Front==1 &&  is_obstacle_right==1)
     {
        direction = 'B';
     }
        
    else{
          direction = 'F';
    }


    return direction;
}

 
 



 int find_victim(Mat image){


    if(!image.data )   // Check for invalid input
    {
        return 0;
    }

   /////////////////////////////////////////////  gray scale    ///////////////////////////////////////////// 
    Mat image_gray;
    cvtColor( image, image_gray, COLOR_BGR2GRAY );


   /////////////////////////////////////////////  Threshold    ///////////////////////////////////////////// 

   Mat image_threshold;
   threshold( image_gray, image_threshold, 127, 255,0 );  //binary

   /////////////////////////////////////////////  find countors  ///////////////////////////////////////////// 
   // Contours can be explained simply as a curve joining all the continuous points (along the boundary),
   // having same color or intensity. The contours are a useful tool for shape analysis and object detection and recognition.
   vector<vector<Point> > contours;
   vector<Vec4i> hierarchy;
   findContours( image_threshold, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0) );


   /////////////////////////////////////////////  find bounding boxes  ///////////////////////////////////////////// 
  /// Approximate contours to polygons + get bounding rects and circles
  vector<vector<Point> > contours_poly( contours.size() );
  vector<Rect> boundRect( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
       boundRect[i] = boundingRect( Mat(contours_poly[i]) );
       int w = boundRect[i].width ;
       int h = boundRect[i].height;
       if (w<20 || h<20 )
          continue;
       if(image.size().width-w <20 || image.size().height-h <20)
          continue; 
       return 1;
     }

    return 0;
  }


 void change_image_format_cv(int image_r[],int image_g[],int image_b[]){


    int photo_size=128;
    image_cv = Mat::zeros(photo_size, photo_size, CV_8UC3);
    int i=0,j=0;
    int x=0;

    for (i=0;i<photo_size;i++){
      for(j=0;j<photo_size;j++){
         image[i][j][0]=image_r[x+j];
         image[i][j][1]=image_g[x+j];
         image[i][j][2]=image_b[x+j];

        Vec3b & color = image_cv.at<Vec3b>(i,j);
        color[0] = image_b[x+j];
        color[1] = image_g[x+j];
        color[2] = image_r[x+j];

    }

      x = x + photo_size;

    }

    // cout << "shape =" << image_cv.size() << "M = " << endl << " " << image_cv << endl << endl;

 }
int is_victim_found(int image_r[],int image_g[],int image_b[],int thermal[],float x,float y,float z){
     // TODO 
     // implement your own find victim condition algorithm
   int i=0;
   int already_visited=0;
   for(i=0;i<visited_victims_num;i++)
       {
          float distance=sqrt(pow(abs(x-visited_victims_x[i]),2)+pow(abs(y-visited_victims_y[i]),2)+pow(abs(z-visited_victims_z[i]),2));
          // cout << distance<<"----"<<x<<"---"<<y<<"-----"<<visited_victims_x[i]<<"\n";
          if(distance <2.5){
            already_visited = 1;
            break;
          }
       }

   if(already_visited == 1)
      return 0;
   change_image_format_cv(image_r,image_g,image_b);
   // change_image_format(image_r,image_g,image_b);
   
   return find_victim(image_cv);

}


 EXPORT char *   start(int _team_size,int _robot_per_team,int _color_sensor_size,int _proximity_sensor_size){
	team_size=_team_size;
	robot_per_team=_robot_per_team;
	color_sensor_size=_color_sensor_size;
	proximity_sensor_size=_proximity_sensor_size;
  server_time=0;
	return "Dragon";
}


EXPORT char *  end(){
	return  "The Ending Message";

 	
}

 void change_image_format(int image_r[],int image_g[],int image_b[]){

    int photo_size=128;
    int i=0,j=0;
    int x=0;

    for (i=0;i<photo_size;i++){
      for(j=0;j<photo_size;j++){
         image[i][j][0]=image_r[x+j];
         image[i][j][1]=image_g[x+j];
         image[i][j][2]=image_b[x+j];
    }
      x = x + photo_size;

    }


 }


 EXPORT char *  play(int colors_1[],int colors_2[],int colors_3[],int proximity_detected[],float proximity_distances[],float pos[],int image_r[],int image_g[],int image_b[],int thermal[],int *led_color_id,float *wheel_linear, float *wheel_angular,float * action_x,float * action_y,float * action_z){

    /* led_color_id: 1---> red  2---> green 3---> blue 4---> off
       colors_1[]: color sensor 1 value, colors are defined by (r,g,b), colors_1[0]-->r value  colors_1[1]-->g value colors_1[2]-->b value
       colors_2[]: color sensor 2 value, colors are defined by (r,g,b), colors_2[0]-->r value  colors_2[1]-->g value colors_3[2]-->b value
       colors_3[]: color sensor 3 value, colors are defined by (r,g,b), colors_3[0]-->r value  colors_2[1]-->g value colors_3[2]-->b value
       
       wheel_linear: linear velocity 
       wheel_angular: angular velocity
       
       proximity_distances[]: values of proximity sensor receptively, you can find the order numbers by clicking on each proximity sensor of robot model in model tree,vrep
       proximity_detected[]: the array length is equal to number of proximity sensor receptively and it's value is 0 or 1 for each proximity. 1 shows that the obstacle is detected
       
       pos[]: pos[0] --> x  pos[1] --> y   pos[2]--> z
       
       return char*: action name if action is detected or empty string
       action_x: the x position of the detected action
       action_y: the y position of the detected action
       action_z: the z position of the detected action
    */
    // Your code will be here

  
 
   char direction = control(proximity_detected,proximity_distances,colors_1,colors_2,colors_3);


    ///////////////// move //////////////
    if (direction == 'F'){
        *wheel_linear =  0.15;
        *wheel_angular  = 0.0;
      }
    if (direction == 'B'){
        *wheel_linear = -0.1; // Set a negative value to make robot go backward (See. Forward)
        *wheel_angular  = 0.0; // Set the 0 value to make robot go backward (See. Forward)
      }
    if (direction == 'L'){
        *wheel_linear = 0.0;
        *wheel_angular  = 0.5;
       }
    if (direction == 'R'){
        *wheel_linear = 0.0; // Set the 0 value to make robot turn right (See. Turn Left)
        *wheel_angular  = -0.3;  // Set a negative value to make robot turn right (See. Turn Left)
      }
    if (direction == 'S'){
        *wheel_linear = 0.0;
        *wheel_angular  = 0.0;
      }
  
  server_time++;



  if (is_victim_found( image_r,image_g,image_b,thermal,pos[0],pos[1],pos[2]))
   {
     *action_x = pos[0];
     *action_y = pos[1];
     *action_z = pos[2];
 
     visited_victims_x[visited_victims_num] = pos[0];
     visited_victims_y[visited_victims_num] = pos[1];
     visited_victims_z[visited_victims_num] = pos[2];
     visited_victims_num++;

     return "find_victim"; // "find_victim_U" for guessing type as U or ..."
   }

 

  return "";

}

}

int main(){
  return 0;
}
